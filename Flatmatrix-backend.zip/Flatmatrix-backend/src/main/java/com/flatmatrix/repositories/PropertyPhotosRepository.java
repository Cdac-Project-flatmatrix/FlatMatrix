package com.flatmatrix.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.flatmatrix.entities.PropertyPhotos;

public interface PropertyPhotosRepository extends JpaRepository<PropertyPhotos, Long> {

}
