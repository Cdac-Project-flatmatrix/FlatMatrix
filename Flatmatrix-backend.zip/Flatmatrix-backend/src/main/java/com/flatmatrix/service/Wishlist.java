package com.flatmatrix.service;

public interface Wishlist {

}
