package com.flatmatrix.service;

public interface MailService {

	void sendEmailNotification(String email, String string, String string2);

}
