package com.flatmatrix.dto;

import lombok.Data;

@Data
public class PropertyPhotosDto {
	private String imageUrl;

}
