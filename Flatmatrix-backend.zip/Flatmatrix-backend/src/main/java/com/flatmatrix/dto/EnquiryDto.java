package com.flatmatrix.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EnquiryDto {
    private Long propertyId;
    private String message;
}