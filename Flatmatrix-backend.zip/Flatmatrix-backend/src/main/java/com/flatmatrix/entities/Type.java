package com.flatmatrix.entities;

public enum Type {
	READY, UNDER_CONSTRUCTION, RESALE
}
