package com.flatmatrix.entities;

public enum Status {
	AVAILABLE, SOLD, RENTED,BOOKED
}
