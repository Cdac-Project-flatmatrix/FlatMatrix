package com.flatmatrix.entities;

public enum EnquiryStatus {
	PENDING, SOLVED
}
