package com.flatmatrix.entities;

public enum Furnished {
	NOT_FURNISHED, SEMI_FURNISHED, FULLY_FURNISHED
}
