package com.flatmatrix.entities;

public enum UserRole {
	SELLER, BUYER
}
